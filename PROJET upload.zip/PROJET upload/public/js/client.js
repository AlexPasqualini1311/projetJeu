var me;
var him;
var go;
var Stop=false;
var hischaracter={};
var mycharacter={};
var PV={};

var users={};

$(document).ready(function() {

    socket.on('refresh',function(user, propriete){
        if (user!=me){
            him = user;
            if (propriete.character){
                cellule=$('td#'+propriete.character);
                joueur2 = cellule.find("span.P2");
                if(!otherChose){
                    joueur2.text(him);
                    otherChose=true;
                    socket.emit('chosen', propriete.character);
                    hischaracter = {name : propriete.character, dic : propriete.properties}
                };
            };
        };
    });

    $('#loginform').submit(function(event){
        event.preventDefault();
        socket.emit('login', $('#username').val());
    });

    socket.on('errorLogin', function(user){
        alert(user + " est déjà utilisé. Choisissez un autre pseudo s'il vous plait")
        $('#username').val('');
    });

    socket.on('toomany', function(){
        alert("Désolé ils sont déjà 2 à jouer..");
    });

    socket.on('logged', function(){
        $('#login').fadeOut();
        me = $('#username').val();

        $('#username').val('');
        $('#username').attr("placeholder", 'Vous êtes connecté');
        $('#logButton').attr("disabled", true);

        $('td.character').click(function(event){
            event.preventDefault();
            joueur1= $(this).find("span.P1");
            
            if (youChose){
                if (joueur1.text() == me){
                    joueur1.text('');
                    youChose=false;
                    socket.emit('unchose', $(this).attr('id'));
                    pret(false)
                    return
                }
            }
            if (!youChose){
                joueur1.text(me);
                youChose=true;
                socket.emit('chose', $(this).attr('id'));
            }
    
            if (otherChose){
                pret(true);
            } 
        });

        $('td.character').mouseover(function(event){
            event.preventDefault();
            socket.emit('getJSON', $(this).attr('id'));
            $('#propandplay').show();
        })
        .mouseout(function(event){
            event.preventDefault();
            $('#properties').find("h2").empty();
            $('#properties').children("ul").empty();
            $('#propandplay').hide();
        })

        $("#play").click(function(event){
            event.preventDefault();
            socket.emit('ready', me);
        });
    });

    socket.on('newusr', function(user){
        alert(`${user} est connecté(e) !`);
        him = user;
        socket.emit('newusr', user);
    });

    socket.on('JSON', function(cell, character){
        name = cell;
        dic = character;

        div=$('#properties');
        div.find("h2").text(name);
        ul = div.find("ul");

        ul.append("<li>attaque : "+dic.attaque+"</li>");
        ul.append("<li>defense : "+dic.defense+"</li>");
        ul.append("<li>PV : "+dic.PV+"</li>");
        ul.append("<li>type : "+dic.type+"</li>");
        ul.append("<li> moveset : <ul></ul> </li>");
        ulul = ul.find("ul");
        cles = Object.keys(dic["moveset"]);
        for (key in cles){
            ulul.append("<li>"+cles[key]+"</li>");
        }
    });

    socket.on('getcharac', function(cell, mycharac) {
        mycharacter.name=cell;
        mycharacter.dic=mycharac;
    })

    socket.on('otherchose', function(cell, hischarac) {
        cellule=$('td#'+cell);
        joueur2 = cellule.find("span.P2");
        if(!otherChose){
            hischaracter.name=cell;
            hischaracter.dic=hischarac;
            joueur2.text(him);
            otherChose=true;
            socket.emit('chosen', cell);
        }

        if (youChose){
            pret(true);
        }
    });

    socket.on('otherunchose', function(cell){
        Stop=true;
        cellule = $('td#'+cell);
        joueur2 = cellule.find("span.P2");
        joueur2.text('');
        otherChose=false;
        pret(false);

    });

    socket.on('wait', function(name){
        $("#select").text('En attente de '+ name);
        });


    socket.on('go', function(){
        $("#select").text('Êtes-vous prêt ?');
        $('#vainqueur').find('.joueur').hide();
        $('#vainqueur').find('button').hide();
        go = true;
        Stop=true;

        users[me]=mycharacter;
        users[him]=hischaracter;
        PV[me]={};
        PV[him]={};

        PV[me].normal=mycharacter.dic.PV;
        PV[me].max=mycharacter.dic.PV;
        PV[him].normal=hischaracter.dic.PV;
        PV[him].max=hischaracter.dic.PV;


        $('.joueur').each(function(index){
            switch (index){
                case 0:
                    $(this).attr('id',mycharacter.name);
                    $(this).find('p.action').each(function(i){
                        $(this).text(Object.keys(mycharacter.dic['moveset'])[i]);
                    });
                    sante(me);
                    break;
                case 1:
                    $(this).attr('id',hischaracter.name);
                    sante(him);
                    break;
            };
        });

        $('#jeu').find('h1').text(me);
        

        $("td.action").bind("click",function(event){
            event.preventDefault();
            socket.emit('action', me, $(this).find("p.action").text());
            $(this).parent().hide();
        });
        $("#selection").fadeOut();
    });

    socket.on('deconnecte', function(user){
        if(go){
            alert(user+' a été déconnecté. veuillez recharger la page.')
        }
        go=false;
        Stop=true;
        joueur = $("span.P2");
        joueur.text('');
        otherChose = false;
        pret(false);
        him = '';
    });

    /* JEU */

    socket.on('tour', function(){
        $('#divjoueur1').find('tr').show();
    });

    socket.on('statistique', function(quoi,comment,qui,combien){
        if (comment=='down'){
            /*animation de descente pour le joueur "qui"*/
            animation(qui,comment,quoi);
            
        }
        else if (comment == 'up'){
            /*animation de montée pour le joueur "qui" */
            animation(qui,comment,quoi);
        }

        else if (comment == 'equal'){
            /*animation de paralysie pour le joueur "qui" */
            animation(qui,'statut');
        };
    });

    socket.on('attaque', function(att, def, move,vie){
        sante(def,vie);
        animation(def,'attaque');
    });

    socket.on('PV',function(att,vie){
        sante(att,vie);
        /* animation de remontée de PV pour att */
    });

    socket.on('invocation', function(etat,att){
        switch (etat){
            case 0:
                animation(att,'PL');

                break;
            case 1:
                animation(att,'loup');
                break;
            case 2:
                commente("c'est déjà la pleine lune..");
                break;
            case 3:
                commente("l'invocation n'a pas fonctionné");
                break;
            case 4:
                commente("Tu as déjà un loup "+att+".. Tu veux quoi de plus ?");
                break;
        };
    });

    socket.on('preparation', function(etat, att,def=undefined,PVatt=NaN,PVdef=NaN){
        switch (etat){
            case 0:
                commente('rien ne se passe');
                break;
            case 1:
                commente('quoi ?! les pv sont échangés');
                sante(att,PVatt,true);
                sante(def,PVdef);
                break;
            case 2:
                commente("plus rien ne peut se passer");
                break;
        }
    });

    socket.on('vainqueur', function(dic){
        vainqueur = $('#vainqueur');
        vainqueur.find('h1').text('Le vainqueur de ce combat est '+dic["name"]);
        vainqueur.find('.joueur').attr('id', dic["character"]);
        setTimeout(function(){
            vainqueur.find('.joueur').fadeIn('slow');
            vainqueur.find("p").text('Félicitations');
            vainqueur.find('button').show();
            vainqueur.find('button').click(function(){
            socket.emit('retourSelection');
        });
    },700);

    });
    socket.on('replay', function(){
            go=false;
            Stop=false;
            hischaracter={};
            mycharacter={};
            PV={};
            users={};
            youChose=false;
            otherChose=false;
            pret(false);

            $('span').each(function(){
                $(this).text('');
            })
            $('#jeu').fadeIn();
            $('#selection').fadeIn();
            $('td.action').unbind("click");
    })
});



function wait(){
    div = $("#wait");
    div.css("background-color", "rgb(255, 0, 64)"); 
    div.animate({width: 300}, "slow"); 
    div.animate({width: 10, left: "+=290"}, "slow");
    div.animate({width: 300, left: "-=290"}, "slow")
    if (!Stop){
    div.animate({width: 10}, "slow",wait);
    }
    else{
        div.hide();
    }
    };

function pret(ready){
    if (ready){
        $('#select').text("Êtes-vous prêts ?");
        $('#play').attr("disabled", false);
        $('#play').css("background-color", "rgba(255, 0, 65, 0.9)");
    }

    else{
        $('#select').text("");
        $('#play').attr("disabled", true);
        $('#play').css("background-color", "grey");
    }
};

function commente(message){
    $("#commentaire").animate(
        {
            now :'+='+message.length
        },
        {
            start : function(){
                $('#commentaire').text(message);
            },
            complete : function(){
                $('#commentaire').text('');
            },
            duration : 1500
        }
    );


};

function sante(personne,pv=false,pvmax=false){
    if (pvmax){
        max1=PV[me].max;
        max2=PV[him].max;
        PV[me].max=max2;
        PV[him].max=max1;
        socket.emit('changement',max2,me,max1,him);
    };
    if(pv === false){
        pv=PV[personne].normal;
    }
    pv=Number(pv);
    PV[personne].normal=Number(PV[personne].normal);
    PV[personne].max=Number(PV[personne].max);
    w=pv/PV[personne].max;
    str = 'div#'+users[personne].name;
    $(str).parent().find('.barre').animate({
        width : (100*w)+"%"
    },{progress : function(animation, progress, msRemaining){
        $(this).prev().text(Math.floor((pv-PV[personne].normal)*progress+PV[personne].normal)+'/'+PV[personne].max);
        if ((pv-PV[personne].normal)*progress+PV[personne].normal<1){
            $(this).prev().text("K.O");
            $(this).css('background-color', '#F22');
        }
        else if ((pv-PV[personne].normal)*progress+PV[personne].normal<=PV[personne].max/10){
            $(this).css('background-color','red');
        }
        else if ((pv-PV[personne].normal)*progress+PV[personne].normal<=PV[personne].max/2){
            $(this).css('background-color', 'orange');
        }
        else {
            $(this).css('background-color', 'green');
        }
    },
    complete : function(){
        $(this).prev().text();
        if(pv !== false){
            PV[personne].normal=pv
        };
        if (pv !== 0){
        $(this).prev().text(PV[personne].normal+'/'+PV[personne].max);
        }
        else{
            $(this).prev().text("K.O");
            $('#jeu').fadeOut('slow');
            socket.emit('perdant',personne); 
        }
    }}).delay(150);
};

function animation(personne,comment, quoi){
    switch (comment){
        case 'attaque':
            $('#joueurs').find('#'+users[personne].name).animate({
                width : "-=20px",
                left : "+=20px"
            },{
                duration : 200,
                start :function(){
                    commente(personne+' est attaqué !')
                },
                complete : function(){
                    $(this).animate({
                        width : "+=20px",
                        left : "-=20px"
                    },{
                        duration : 200
                    });
                }
            });
            break;
        case 'PL':
            joueur=$('#joueurs').find('#'+users[personne].name)
            joueur.append("<img id='lune' src='/stylesheet/img/lune.png' alt='lune'>");
            joueur.find('#lune').animate({
                opacity : "100%"
            },{duration : 1000,
                start : function(){
                    commente('La pleine Lune se lève');
                },
            complete : function(){
                $(this).animate({
                    opacity : '0%'
                },{duration : 1000,
                }
            )}
            });
            setTimeout(function(){
                joueur.find("#lune").remove()
            },1900);
        break;
        case 'loup':
            joueur=$('#joueurs').find('#'+users[personne].name)
            joueur.append("<img id='loup' src='/stylesheet/img/loup.png' alt='loup'>");
            joueur.find('#loup').animate({
                opacity : "100%"
            },{duration : 1000,
                start : function(){
                    commente(personne+" a invoqué un loup ! il va l'aider dans son combat !");
                },  
            complete : function(){
                $(this).animate({
                    opacity : '0%'
                },{duration : 1000}
            )}
            });
            setTimeout(function(){
                joueur.find("#loup").remove()
            },2000);
        break;
        case 'up':
            joueur=$('#joueurs').find('#'+users[personne].name)
            joueur.append("<img id='up' src='/stylesheet/img/up.png' alt='up'>");
                joueur.find('#up').animate({
                    opacity : "100%"
                },{duration : 495,
                    start : function(){
                        commente('la statistique '+quoi+' de '+personne+' a augmentée !');
                    },
                complete : function(){
                    $(this).animate({
                        opacity : '0%'
                    },{duration : 495}
                )}
                });
                setTimeout(function(){
                    joueur.find('#up').animate({
                        opacity : "100%"
                    },{duration : 495,
                    complete : function(){
                        $(this).animate({
                            opacity : '0%'
                        },{duration : 495}
                    )}
                    });},900);
                    setTimeout(function(){
                        joueur.find("#up").remove()
                    },2000);
        break;
        case 'down':
            joueur=$('#joueurs').find('#'+users[personne].name)
            joueur.append("<img id='down' src='/stylesheet/img/down.png' alt='down'>");
                joueur.find('#down').animate({
                    opacity : "100%"
                },{duration : 500,
                    start : function(){
                        commente('la statistique '+quoi+' de '+personne+' a diminuée');
                    },
                complete : function(){
                    $(this).animate({
                        opacity : '0%'
                    },{duration : 500}
                )}
                });
                setTimeout(function(){
                    joueur.find('#down').animate({
                        opacity : "100%"
                    },{duration : 495,
                    complete : function(){
                        $(this).animate({
                            opacity : '0%'
                        },{duration : 495}
                    )}
                    });},900);
                setTimeout(function(){
                    joueur.find("#down").remove()
                },2000);
        break;
        case 'statut':
            joueur=$('#joueurs').find('#'+users[personne].name);
            joueur.append("<img id='statut' src='/stylesheet/img/statut.png' alt='statut'>");
                joueur.find('#statut').animate({
                    opacity : "100%"
                },{duration : 495,
                    start : function(){
                        commente(personne+' est paralysé(e)');
                    },
                complete : function(){
                    $(this).animate({
                        opacity : '0%'
                    },{duration : 495}
                )}
                });
                setTimeout(function(){
                    joueur.find('#statut').animate({
                        opacity : "100%"
                    },{duration : 495,
                    complete : function(){
                        $(this).animate({
                            opacity : '0%'
                        },{duration : 495}
                    )}
                    });},900);
                    setTimeout(function(){
                        joueur.find("#statut").remove()
                    },2000);
        break;
    };
}