({
  'list': [
		['', 'emptyString'],
		[[], 'emptyArray'],
		[0, 'zero'],
		[null, 'null'],
		[undefined, 'undefined'],
		[0/0, 'NaN']
  ]
});