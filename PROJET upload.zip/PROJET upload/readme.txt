Le jeu proposé est un jeu vidéo multijoueur de combat en tour par tour.
Il s'inspire de mécaniques du jeu pokémon.

Pour jouer veuillez :
    lancer le server "server.js"
    dans votre navigateur ouvrir 2 pages localhost:1337
    entrez un pseudo différent dans chaque page (le jeu saura vous le rappeler dans le cas contraire)
    dans chaque page  : 
        choisir un personnage
        cliquer sur jouer lorsque celui-ci est rouge
        une fois dans le combat les attaques du joueur sont sur son icone en haut
        choisissez-en une et elle disparaitrons jusqu'au prochain tour
        le tour se passe
        et on recommence jusqu'au K.O d'un des joueurs
        le vainqueur est célèbré puis n'importe qui peut relancer le jeu en cliquant sur retour au choix des personnages.

Les + du jeu : 
    impossibilité de choisir le même pseudo
    impossibilité de logger 3 participants
    possibilité de voir les caractéristiques des personnage en survolant leur icone de selection
    possibilité de changer de personnage en cliquant à nouveau sur le personnage choisi

    des animations pour toutes les attaques
    le premier joueur à attaquer est random à chaque tour
    animations des barres de vie de chacun
    des commentaires intéressants à chaque action
    un système de "type"  donne une relation de force et faiblesse à chaque personnage
    des attaques aux conséquences différentes.

    possibilité de rejouer en fin de combat

On pourrait ajouter :
    la visibilité on non du choix de l'adversaire (évite le choix du personnage en fonction de celui choisi par l'adversaire).
    plus de personnages

et bien d'autres chose mais comme c'est un jeu vidéo vous devrez attendre les futurs patchs.