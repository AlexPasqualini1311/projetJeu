var express = require('express');
var app = express();
var http = require('http').createServer(app);
var io = require('socket.io')(http);
var nombreUser=0;
var users = {};

var tour = {};
var PL = false;
var invoque = false;
var compteur=0;

app.use(express.static('public'))

let myJSON ='{"Muhamad":{"attaque" : "100","defense" : "40","PV" : "100","type" : "soleil","fortContre" : ["lune","CAC"],"faibleContre" : ["lune","magie"],"moveset" : { "brûlure" : "attaque","vitalité" : "PV","barrière" : "maDefense"}},"Michelle":{"attaque" : "140","defense" : "20","PV" : "70","type" : "magie","fortContre" : ["soleil"],"faibleContre" : ["lune","CAC"],"moveset" : { "BouleNégative" : "attaque","Paralysie" : "statut","Préparation" : "préparation"}},"Carlos":{"attaque" : "80","defense" : "60","PV" : "100","type" : "CAC","fortContre" : ["magie"],"faibleContre" : ["soleil"],"moveset" : { "coupDirect" : "attaque","lameDeCourage" : "monAttaque","BriseCasque" : "saDefense"}},"Chen":{"attaque" : "14","defense" : "30","PV" : "120","type" : "lune","fortContre" : ["soleil", "magie"],"faibleContre" : ["soleil"],"moveset" : { "pleineLune" : "PleineLune","invocation" : "invocation","coupPorté" : "attaque"}}}';
var characters = JSON.parse(myJSON);  

io.on('connection', function(socket){
    var me = {};
    var him = {};

    socket.on('login', function(user){
        console.log(nombreUser);
        
        if (nombreUser<2){
            if (!users[user]){
                nombreUser++;
                me = {username : user};
                users[me.username] = me;
                socket.broadcast.emit('newusr', me.username);
                socket.emit('logged');
                for (var i in users){
                        socket.emit('refresh', i, users[i]);
                };
            }
            else{
                socket.emit('errorLogin', user);
            };
        }
        else{
            socket.emit('toomany');
        }
    });

    socket.on('newusr', function(user){
        him = {username : user};
    });

    socket.on('getJSON', function(cell){
        socket.emit('JSON', cell, characters[cell]);
    });

    socket.on('chose', function(cell){
        me.character = cell;
        me.properties = clone(characters[cell]);
        me.PVmax = characters[me.character].PV;
        socket.broadcast.emit('otherchose', cell, characters[cell]);
        socket.emit('getcharac', cell, characters[cell]);
    });

    socket.on('unchose', function(cell){
        socket.broadcast.emit('otherunchose', cell);
    });

    socket.on('chosen', function(cell){
        him.character = cell;
    });

    socket.on('ready', function(name){
        me.ready = true;
        for (key in users){
            if (key !=name){
                if (!users[key]["ready"]){
                    socket.emit('wait', key);
                }
                else{
                    io.emit('go');
                    io.emit('tour'); 
                };
            };
        };
    });
    
    socket.on('disconnect', function(){
        if (nombreUser>0)
        {nombreUser--;};
        socket.broadcast.emit('deconnecte', me.username);
        delete users[me.username];
        tour = {};
        PL = false;
        invoque = false;
        compteur=0;
    });

    /* JEU */

    socket.on('action', function(user, move){
        tour[user] = move;
        keys = Object.keys(tour);
        if (keys[1]){
            numero = Math.floor(2*Math.random());
            premier = keys[numero];
            second = keys[1-numero];
            action(premier,second,tour[premier]);
            setTimeout(function(){
                action(second,premier,tour[second]);
                setTimeout(function(){
                    io.emit('tour');
                    tour={};
                },2000);
            }, 2000);
        };  
    });

    socket.on('changement', function(max1,att,max2,def){
        users[att].PVmax = max1;
        users[def].PVmax = max2;
    });

    socket.on('perdant',function(perdant){
        keys= Object.keys(users);
        for ( i in keys){
            if (keys[i] != perdant){
                vainqueur = {name : keys[i], character : users[keys[i]].character};
                io.emit('vainqueur', vainqueur);
                return;
            };
        }
    });

    socket.on('retourSelection', function(){
        tour = {};
        PL = false;
        invoque = false;
        compteur=0;
        delete users[me.username].ready;
        delete users[him.username].ready;
        io.emit('replay');
    });

});

http.listen(1337, function(){
    console.log('listenning on *:1337');
});

function action(attaquant, defenseur, move){
    typeAttaque = users[attaquant].properties.moveset[move];
    statut = users[attaquant].statut;
    if (statut){
        if (Math.random()>=0.7){
            statut = false;
            users[attaquant].statut = statut;
            io.emit('statistique', 'statut', 'up', attaquant,'paralysé');
        }
        else{
        io.emit('statistique','statut','equal', attaquant,'paralysé');
        return
        };
    };
    if (typeAttaque == 'attaque'){
        att = users[attaquant].properties.attaque;
        def = users[defenseur].properties.defense;

        typeatt = users[attaquant].properties.type;
        typedef = users[defenseur].properties.type;


        if (In(users[attaquant].properties.fortContre,typedef)){
            CM = 2;
        }
        else if (In(users[attaquant].properties.faibleContre,typedef)){
            CM = 0.5;
        }
        else {
            CM = 1;
        };
        PVperdu = Math.floor((2+(2*att)/(def))*CM);
        PV = users[defenseur].properties.PV;
        if(PV-PVperdu > 0){
            PV-=PVperdu;
        }

        else{
            PV=0;
        };
        users[defenseur].properties.PV = PV;
        io.emit('attaque', attaquant, defenseur, move,PV);
        return
    }
    else if (typeAttaque == 'PV'){
        PV = users[attaquant].properties.PV;
        PVmax = users[attaquant].PVmax;
        PVrendu = Math.floor(PVmax*Math.random());

        if(PV+PVrendu<=PVmax){
            PV+=PVrendu;
        }
        else{
            PV=PVmax;
        }
        users[attaquant].properties.PV=PV;
        io.emit('PV',attaquant,PV);
        return
    }
    else if(typeAttaque == 'maDefense'){
        def= users[attaquant]["properties"]["defense"];
        def*=2;
        users[attaquant]["properties"]["defense"]=def;
        io.emit('statistique', 'defense', 'up', attaquant,def);
        return
    }
    else if (typeAttaque == 'saDefense'){
        def= users[defenseur]["properties"]["defense"];
        def*=0.35;
        users[defenseur]["properties"]["defense"]=def;
        io.emit('statistique', 'defense', 'down', defenseur,def);
        return
    }
    else if (typeAttaque == 'monAttaque'){
        att= users[attaquant]["properties"]["attaque"];
        att*=2;
        users[attaquant]["properties"]["attaque"]=att;
        io.emit('statistique', 'attaque', 'up', attaquant,att);
        return
    }
    else if (typeAttaque == 'statut'){
        users[defenseur].statut = true;
        io.emit('statistique', 'statut', 'equal', defenseur, 'paralysé');
        return
    }
    else if (typeAttaque == 'préparation'){
        compteur++
        if (compteur==3){
            mPV = users[attaquant].properties.PV;
            sPV= users[defenseur].properties.PV;

            a=mPV;
            mPV=sPV;
            sPV=a;
            users[attaquant].properties.PV=mPV;
            users[defenseur].properties.PV=sPV;
            io.emit('preparation',1,attaquant,defenseur,mPV,sPV);
            return
        }
        else if(compteur<3){
            io.emit('preparation',0,attaquant);
            return
        }
        else{
            io.emit('preparation',2,attaquant);
            return
        }
    }
    else if (typeAttaque == 'PleineLune'){
        if (!PL){
            PL =true;
            io.emit('invocation' ,0 ,attaquant);
            return
        }
        else{
            io.emit('invocation' ,2 ,attaquant);
            return
        }
    }
    else if (typeAttaque == 'invocation'){
        if (PL){
            if(invoque){
            io.emit('invocation' ,4 ,attaquant);
            return
            };
            att = users[attaquant]["properties"]["attaque"]
            att*=10; 
            users[attaquant]["properties"]["attaque"] = att;
            io.emit('invocation' ,1 ,attaquant);
            invoque=true;
            return
        };
        io.emit('invocation' ,3 ,attaquant);
        return
    };
};

function clone(obj){
	try{
		var copy = JSON.parse(JSON.stringify(obj));
	} catch(ex){
		alert("Vous utilisez un vieux navigateur bien pourri, qui n'est pas pris en charge par ce site");
	}
    return copy
}

function In(tableau, valeur){
    for (var i in tableau){
        if (tableau[i] ===valeur){
            return true
        }
    }
    return false
};